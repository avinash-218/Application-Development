/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MYPC
 */
import java.util.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DBHandler {
    Connection con;
    Statement stmt;
    public DBHandler(String user,String pass) throws SQLException		//default constructor
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.5:1521:orcl",user,pass);
            con.setAutoCommit(false);
            stmt = con.createStatement();
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
    }
    
    public boolean verify_user(String user,String pass) //verify user's login and password
    {
        boolean x=false;
        try
        {
            String query = "SELECT PASSWORD FROM LOGINS WHERE USERNAME LIKE '"+user+"'";
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next())
            {
                if(rs.getString("PASSWORD").equals(pass))
                    x = true;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
            x = false;
        }
        return x;
    }
    
    public boolean check_unique_user(String user) //verify user's login and password
    {
        boolean x=false;
        try
        {
            String query = "SELECT COUNT(*) FROM LOGINS WHERE USERNAME LIKE '"+user+"'";
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next())
            {
                if(rs.getString(1).equals("1"))
                    return true;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
            return false;
        }
        return x;
    }
    
    public int add_User(String user,String pass)
    {
        int x=0;
        try
        {
            String query = "INSERT INTO LOGINS VALUES('"+user+"','"+pass+"')";
            x=stmt.executeUpdate(query);
        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("102");
        }
        return x;
    }
    
    public int create_User(String name,String pass)
    {
        int x=0;
        try
        {
            String query = "ALTER SESSION SET \"_ORACLE_SCRIPT\"=true";
            stmt.executeUpdate(query);
            x++;
            query = "CREATE USER "+name+" IDENTIFIED BY "+pass;
            stmt.executeUpdate(query);
                x++;
            query = "GRANT ALL PRIVILEGES TO "+name;
            stmt.executeUpdate(query);
                x++;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
    
    public int create_Tables()
    {
        int x=0;
        try
        {
            String query = "CREATE TABLE TRANSACTIONS(NO NUMBER(3) PRIMARY KEY, ACCOUNTS VARCHAR(15) NOT NULL, DATE_TIME CHAR(20) NOT NULL, STATUS VARCHAR(30) NULL, COMMENTS VARCHAR(50) NULL)";
            stmt.executeUpdate(query);
                x++;
            query = "CREATE TABLE ACCOUNTS(NO NUMBER(2) PRIMARY KEY, NAME VARCHAR(35) NOT NULL, BALANCE NUMERIC(12,2) NOT NULL)";
            stmt.executeUpdate(query);
                x++;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
    
    public void update_no(String tab, int no)  //reorder serial numbers after delete in tables
    {
       int cnt,x=0;
       try
       {
           cnt=count_table(tab)+1;
           String query = "DECLARE\n"
                    +"I NUMBER;\n"+
                    "BEGIN\n"+
                    "FOR I IN "+no+".."+cnt+" LOOP\n"+
                    "UPDATE "+tab+" SET NO = I-1 WHERE NO = I;\n"+
                    "END LOOP;\n"+
                    "END;\n";//+
                    //"/\n";
           x = stmt.executeUpdate(query);
       }
       catch(Exception e)
       {
           System.out.println(e);
       }

    }
     
    public int count_table(String table)
    {
        int x=0;
        try
        {
            String query="SELECT COUNT(*) FROM "+table;
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            x = rs.getInt(1);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
    
    public boolean checkUniqueName_accounts(String name)//check for duplicate account names
	{
            boolean x=false;
            try
            {
                String query="SELECT * FROM ACCOUNTS WHERE NAME='" + name + "'";
                ResultSet rs=stmt.executeQuery(query);
                x=rs.next();
            }
            catch(Exception ex)
            {
                System.out.println(ex);
            }
            return x;
	}
    
    public int create_in_accounts(String name,Double bal)    //insert into accounts table when account created
    {
        int count = count_table("ACCOUNTS")+1;
        int x=0;
        try
        {
            String query="INSERT INTO ACCOUNTS VALUES(" + count +",'"+name+"',"+bal+")";
            x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
    
    public Double get_Balance(String name)  //get balance of account
    {
        Double bal=0.0;
        try
        {
            String query = "SELECT BALANCE FROM ACCOUNTS WHERE NAME LIKE '"+name+"'";
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next())
                bal = Double.parseDouble(rs.getString("BALANCE"));
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return bal;
    }
    
    public int add_transaction(int no,String name, String date_time,String status, String comments) //insert into transactions table
    {
        int count;
        if(no==0)
            count = count_table("TRANSACTIONS")+1;
        else
            count=no;
        int x=0;
        try
        {
            String query="INSERT INTO TRANSACTIONS VALUES(" + count +",'"+name+"','"+date_time+"','"+status+"','"+comments+"')";
            x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
    
    public int delete_in_accounts(String name)    //delete from accounts table when account deleted
    {
        int x=0;
        try
        {
            String query="DELETE FROM ACCOUNTS WHERE NAME='"+name+"'";
            x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
 
    public int rename_in_tables(String oldName,String newName)
    {
        int x=0;
        String query="";
        try
        {
            query="UPDATE ACCOUNTS SET NAME='" + newName + "'" + "where Name='" + oldName + "'";
            stmt.executeUpdate(query);
            x++;
            query="UPDATE TRANSACTIONS SET ACCOUNTS='" + newName + "'" + "where ACCOUNTS='" + oldName + "'";
            stmt.executeUpdate(query);
            x++;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
    
     public int update_acc(String name,Double amnt) //update account balance
     {
        int x=0;
        Double bal = get_Balance(name);
        if(amnt<0)
            if(bal < -amnt)
                return -3;
        bal = bal + amnt;
        try
        {
            String query="UPDATE ACCOUNTS SET BALANCE="+bal+" where NAME='" + name + "'";
            x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
     }
     
     public int clear_table(String tab)	//clear table
    {
        int x=0;
        try
        {
                String query="TRUNCATE TABLE "+tab;
                x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
                System.out.println(ex);
        }
        return x;
    }
     
     public ResultSet get_Transaction(int num)	//get the transaction in the index in the table transactions
    {
        ResultSet row;
        try
        {
            String query="SELECT * FROM TRANSACTIONS WHERE NO="+num;
            row=stmt.executeQuery(query);
            if(row.next())
                return row;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return null;
    }
     
     public int delete_transaction(int id)		//remove the transaction details in the index in transactions table
    {
        int x=0;
        try
        {
            String query="DELETE FROM TRANSACTIONS WHERE NO="+id;
            x=stmt.executeUpdate(query);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
     
    public void commit()   //commit transactions
    {
        try
        {
            con.commit();
        }
        catch(Exception e)
        {
             System.out.println(e);
        }
    }
     
    public void roll_back()   //rollback transactions
    {
        try
        {
            con.rollback();
        }
        catch(Exception e)
        {
             System.out.println(e);
        }
    }
     
    public void roll_back_to_check(String chk_name)   //rollback transactions
    {
        try
        {
            Savepoint spt = con.setSavepoint(chk_name);
            con.rollback(spt);
        }
        catch(Exception e)
        {
             System.out.println(e);
        }
    }
    
    public int count_Transactions(String acc_name,String date,int ch)		//count the number of rows in the table transactions
    {
        int x=0;
        String query;
        try
        {
            if (ch==1)
                query="SELECT COUNT(*) FROM TRANSACTIONS WHERE ACCOUNTS='"+acc_name+"'";
            else if (ch==2)
                query="SELECT COUNT(*) FROM TRANSACTIONS WHERE DATE_TIME LIKE'"+date+"%'";
            else
                query="SELECT COUNT(*) FROM TRANSACTIONS WHERE ACCOUNTS='"+acc_name+"' AND DATE_TIME LIKE'"+date+"%'";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            x = rs.getInt(1);
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return x;
    }
     
    public ResultSet get_Accounts(int index)	//get the account in the index in the table Accounts
    {
        ResultSet row;
        try
        {
            String query="SELECT * FROM ACCOUNTS ORDER BY NO ASC OFFSET "+index+" ROWS FETCH NEXT 1 ROWS ONLY";
            row=stmt.executeQuery(query);
            if(row.next())
                return row;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return null;
    }
     
    
    public ResultSet get_Transactions(String acc_name,String date,int choice,int index)		//get the records sorted by datetime
    {
        ResultSet row;
        String query;
        try
        {
            if(choice==1)
                //String query="SELECT * FROM ACCOUNTS ORDER BY NO ASC OFFSET "+index+" ROWS FETCH NEXT 1 ROWS ONLY";
                query="SELECT * FROM TRANSACTIONS WHERE ACCOUNTS ='"+acc_name+"' ORDER BY NO ASC OFFSET "+index+" ROWS FETCH NEXT 1 ROWS ONLY";
            else if (choice==2)
                query="SELECT * FROM TRANSACTIONS WHERE DATE_TIME LIKE'"+date+"%' ORDER BY NO ASC OFFSET "+index+" ROWS FETCH NEXT 1 ROWS ONLY";
            else
                query="SELECT * FROM TRANSACTIONS WHERE ACCOUNTS='"+acc_name+"' AND DATE_TIME LIKE'"+date+"%' ORDER BY NO ASC OFFSET "+index+" ROWS FETCH NEXT 1 ROWS ONLY";

            row=stmt.executeQuery(query);
            if(row.next())
                return row;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return null;
    }

    public void save_Point(String check_pt_name)
    {
        try 
        {
            Savepoint spt1 = con.setSavepoint(check_pt_name);
        }
        catch(SQLException ex) 
        {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int delete_user(String user)
    {
        int x=0;
        try
        {
            String query = "DELETE FROM LOGINS WHERE USERNAME = '"+user+"'";
            x=stmt.executeUpdate(query);
            stmt.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
    
    public int update_pass(String user,String new_pass)
    {
        int x=0;
        try
        {
            String query = "UPDATE LOGINS SET PASSWORD = '"+new_pass+"' WHERE USERNAME = '"+user+"'";
            x=stmt.executeUpdate(query);
            stmt.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
        
    public int drop_user(String user)
    {
        int x=0;
        try
        {
            String query = "ALTER SESSION SET \"_ORACLE_SCRIPT\"=true";
            stmt.executeUpdate(query);
            x++;

            query = "SELECT SID,SERIAL#,STATUS FROM v$session WHERE USERNAME = '"+user.toUpperCase()+"'";
            ResultSet rs=stmt.executeQuery(query);
            rs.next();
            int sid = rs.getInt(1);
            int serial = rs.getInt(2);
            x++;
            
            String sess = String.valueOf(sid) + "," + String.valueOf(serial);
            query = "ALTER SYSTEM KILL SESSION '"+sess+"' immediate";
            stmt.executeUpdate(query);
            x++;
            
            query = "DROP USER "+ user + " CASCADE";
            stmt.executeUpdate(query);
            x++;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
    
    public int reset_pass(String user, String new_pass,String old_pass)
    {
        int x=0;
        try
        {
            String query = "ALTER USER "+user+" IDENTIFIED BY \""+new_pass+"\" REPLACE \""+old_pass+"\"";
            stmt.executeUpdate(query);
            x++;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return x;
    }
    
}