//user defined exception
public class User_Exception extends Exception
{
	User_Exception(String msg)
	{
		super(msg);
	}
}